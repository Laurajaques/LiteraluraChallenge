package br.com.literalura;

import br.com.literalura.dto.AutorDTO;
import br.com.literalura.dto.LivroDTO;
import br.com.literalura.dto.ResultadoDTO;
import br.com.literalura.model.Autor;
import br.com.literalura.model.Livro;
import br.com.literalura.repository.AutorRepository;
import br.com.literalura.repository.LivroRepository;
import br.com.literalura.service.ConsumoApi;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.PageRequest;

import java.text.Normalizer;
import java.util.Optional;
import java.util.Scanner;

@SpringBootApplication
public class LiteraluraAplication implements CommandLineRunner {

    @Autowired
    private AutorRepository autorRepository;

    @Autowired
    private LivroRepository livroRepository;

    @Autowired
    private ConsumoApi api;

    public static void main(String[] args) {
        SpringApplication.run(LiteraluraAplication.class, args);
    }

    private String removerAcentos(String texto) {
        return Normalizer
                .normalize(texto, Normalizer.Form.NFD)
                .replaceAll("[^\\p{ASCII}]", "");
    }

    @Override
    public void run(String[] args) throws Exception {

        Scanner scanner = new Scanner(System.in);
        int opcao = -1;

        while (opcao != 0) {
            System.out.println("""
                    
                    ****** LITERALURA ******
                    1 - Cadastrar autor manualmente
                    2 - Listar autores
                    3 - Buscar livro na API
                    4 - Listar livros
                    5 - Buscar autores vivos em determinado ano
                    6 - Listar livros por idioma
                    7 - Top 10 livros mais baixados
                    
                    0 - Sair
                    """);

            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {

                case 1:
                    System.out.println("Digite o nome do autor:");
                    String nome = scanner.nextLine();

                    System.out.println("Ano de nascimento:");
                    int nascimento = scanner.nextInt();

                    System.out.println("Ano de falecimento:");
                    int falecimento = scanner.nextInt();
                    scanner.nextLine();

                    Autor autor = new Autor(nome, nascimento, falecimento);
                    autorRepository.save(autor);

                    System.out.println("Autor salvo com sucesso!");
                    break;

                case 2:
                    System.out.println("Autores cadastrados:");
                    autorRepository.findAll()
                            .forEach(System.out::println);
                    break;

                case 3:
                    System.out.println("Digite o nome do livro para buscar:");
                    String busca = scanner.nextLine();

                    String buscaFormatada = removerAcentos(busca).replace(" ", "%20");

                    String json = api.obterDados("https://gutendex.com/books/?search=" + buscaFormatada);

                    ObjectMapper mapper = new ObjectMapper();
                    ResultadoDTO resultado = mapper.readValue(json, ResultadoDTO.class);

                    if (resultado.resultados().isEmpty()) {
                        System.out.println("Livro não encontrado!");
                        break;
                    }

                    LivroDTO livroDTO = resultado.resultados().get(0);
                    AutorDTO autorDTO = livroDTO.autores().get(0);

                    Autor autorApi = autorRepository
                            .findByNome(autorDTO.nome())
                            .orElseGet(() -> { Autor novoAutor = new Autor(
                                        autorDTO.nome(),
                                        autorDTO.nascimento(),
                                        autorDTO.falecimento());
                                return autorRepository.save(novoAutor);
                            });

                    Optional<Livro> livroExistente =
                            livroRepository.findByTitulo(livroDTO.titulo());

                    if (livroExistente.isPresent()) {
                        System.out.println("Livro já cadastrado!");
                    } else {
                        Livro livro = new Livro(
                                livroDTO.titulo(),
                                livroDTO.idiomas().get(0),
                                livroDTO.downloads(),
                                autorApi);

                        livroRepository.save(livro);
                        System.out.println("Livro salvo com sucesso!");
                    }
                    break;

                case 4:
                    System.out.println("Livros cadastrados:");
                    livroRepository.findAll()
                            .forEach(System.out::println);
                    break;

                case 5:
                    System.out.println("Digite o ano:");
                    int ano = scanner.nextInt();
                    scanner.nextLine();

                    var autoresVivos = autorRepository.autoresVivosNoAno(ano);

                    if (autoresVivos.isEmpty()) {
                        System.out.println("Nenhum autor encontrado nesse ano");
                    } else {
                        autoresVivos.forEach(System.out::println);
                    }
                    break;

                case 6:
                    System.out.println("Digite o idioma (ex: pt, fr):");
                    String idioma = scanner.nextLine();

                    var livrosPorIdioma = livroRepository.findByIdioma(idioma);

                    if (livrosPorIdioma.isEmpty()) {
                        System.out.println("Nenhum livro encontrado nesse idioma");
                    } else {
                        livrosPorIdioma.forEach(System.out::println);
                    }
                    break;

                case 7:

                    var pageable = PageRequest.of(0, 10);
                    var topLivros = livroRepository.topLivros(pageable);
                    if (topLivros.isEmpty()) {
                        System.out.println("Nenhum livro cadastrado");
                    } else {
                        System.out.println("***** TOP 10 LIVROS MAIS BAIXADOS *****");
                        topLivros.forEach(System.out::println);
                    }
                    break;

                case 0:
                    System.out.println("Encerrando...");
                    break;

                default:
                    System.out.println("Opçao inválida");
            }
        }
    }
}